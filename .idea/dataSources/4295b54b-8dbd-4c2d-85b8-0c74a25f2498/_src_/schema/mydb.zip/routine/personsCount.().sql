CREATE PROCEDURE personsCount(OUT res INT)
  BEGIN
  SELECT count(*) into res from personse;
END;
