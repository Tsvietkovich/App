CREATE PROCEDURE getPersonse(IN firstName VARCHAR(20), IN lastName VARCHAR(20), IN telephone VARCHAR(20),
                             IN birthDay  DATE)
  BEGIN
    SELECT * FROM personse WHERE FirstName=firstName AND LastName=lastName AND Telephone=telephone AND BirthDay=birthDay;
  END;
